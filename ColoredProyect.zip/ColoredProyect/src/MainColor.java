import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainColor {
	private static String colored(Object obj, String color) {
		String s = null;
		String stype = "";
		if(obj instanceof String) {stype = "String";}
		else if(obj instanceof Integer){stype = "int";}
		else if(obj instanceof ArrayList){stype = "ArrayList";}
		else if(obj instanceof Arrays){stype = "Array";}
		else if(obj instanceof List){stype = "List";}
		else {System.out.println(colored("\n\nNON VALID COLORED VAR TYPE", "mate_red"));}
		
		
		if(stype.equals("String") || stype.equals("int")) {		
			s = "" + obj.toString();
			//TYPOGRAPHIC
			if(color.equalsIgnoreCase("textonegrita"))  {s=("\u001b[1;1m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("textocursiva"))  {s=("\u001b[1;3m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("textosubrayado"))  {s=("\u001b[1;4m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("black_white"))  {s=("\u001b[1;7m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("black_black"))  {s=("\u001b[1;8m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("tachado"))  {s=("\u001b[1;9m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("2subrayado"))  {s=("\u001b[1;21m"+ s +"\u001b[0m");}
			//STANDARD COLORS
			if(color.equalsIgnoreCase("black"))  {s=("\u001b[1;30m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("red"))  {s=("\u001b[1;31m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("green"))  {s=("\u001b[1;32m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("yellow"))  {s=("\u001b[1;33m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("blue"))  {s=("\u001b[1;34m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("magenta"))  {s=("\u001b[1;35m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("cyan"))  {s=("\u001b[1;36m"+ s +"\u001b[0m");}
			//BACKGROUNDED COLORS
			if(color.equalsIgnoreCase("white_red"))  {s=("\u001b[1;41m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_green"))  {s=("\u001b[1;42m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_yellow"))  {s=("\u001b[1;43m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_blue"))  {s=("\u001b[1;44m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_magenta"))  {s=("\u001b[1;45m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_cyan"))  {s=("\u001b[1;46m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_gray"))  {s=("\u001b[1;47m"+ s +"\u001b[0m");}
			//UPDATE COLOR BOXES
			if(color.equalsIgnoreCase("white_box"))  {s=("\u001b[1;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("red_box"))  {s=("\u001b[31;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("green_box"))  {s=("\u001b[32;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("yellow_box"))  {s=("\u001b[33;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("blue_box"))  {s=("\u001b[33;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("magenta_box"))  {s=("\u001b[34;51m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("cyan_box"))  {s=("\u001b[35;51m"+ s +"\u001b[0m");}
			//MATE COLORS
			if(color.equalsIgnoreCase("mate_red"))  {s=("\u001b[1;91m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("mate_green"))  {s=("\u001b[1;92m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("mate_yellow"))  {s=("\u001b[1;93m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("mate_blue"))  {s=("\u001b[1;94m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("mate_magenta"))  {s=("\u001b[1;95m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("mate_cyan"))  {s=("\u001b[1;96m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("white_darkgray"))  {s=("\u001b[1;100m"+ s +"\u001b[0m");}
			if(color.equalsIgnoreCase("damif"))  {s=("\u001b[38;5;162m"+ s +"\u001b[0m");}
			}
		return s;
	}
	public static void main(String[] args) {
		//TYPOGRAPHIC
		System.out.println(colored("Hola MOai " , "textonegrita") + "   --   textonegrita");
		System.out.println(colored("Hola MOai " , "textocursiva") + "   --   textocursiva");
		System.out.println(colored("Hola MOai " , "textosubrayado") + "   --   textosubrayado");
		System.out.println(colored("Hola MOai " , "black_white") + "   --   black_white");
		System.out.println(colored("Hola MOai " , "black_black") + "   --   black_black");
		System.out.println(colored("Hola MOai " , "tachado") + "   --   tachado");
		System.out.println(colored("Hola MOai " , "2subrayado") + "   --   2subrayado");
		
		//STANDARD COLORS
		System.out.println(colored("\n\nHola MOai " , "black") + "   --   black");
		System.out.println(colored("Hola MOai " , "red") + "   --   red");
		System.out.println(colored("Hola MOai " , "green") + "   --   green");
		System.out.println(colored("Hola MOai " , "yellow") + "   --   yellow");
		System.out.println(colored("Hola MOai " , "blue") + "   --   blue");
		System.out.println(colored("Hola MOai " , "magenta") + "   --   magenta");
		System.out.println(colored("Hola MOai " , "cyan") + "   --   cyan");
		
		//BACKGROUNDED COLORS
		System.out.println(colored("\n\nHola MOai " , "white_red") + "   --   white_red");
		System.out.println(colored("Hola MOai " , "white_green") + "   --   white_green");
		System.out.println(colored("Hola MOai " , "white_yellow") + "   --   white_yellow");
		System.out.println(colored("Hola MOai " , "white_blue") + "   --   white_blue");
		System.out.println(colored("Hola MOai " , "white_magenta") + "   --   white_magenta");
		System.out.println(colored("Hola MOai " , "white_cyan") + "   --   white_cyan");
		System.out.println(colored("Hola MOai " , "white_gray") + "   --   white_gray");

		//UPDATE COLOR BOXES
		System.out.println(colored("\n\nHola MOai " , "white_box") + "   --   white_box");
		System.out.println(colored("Hola MOai " , "red_box") + "   --   red_box");
		System.out.println(colored("Hola MOai " , "green_box") + "   --   green_box");
		System.out.println(colored("Hola MOai " , "yellow_box") + "   --   yellow_box");
		System.out.println(colored("Hola MOai " , "blue_box") + "   --   blue_box");
		System.out.println(colored("Hola MOai " , "magenta_box") + "   --   magenta_box");
		System.out.println(colored("Hola MOai " , "cyan_box") + "   --   cyan_box");
		
		//MATE COLORS
		System.out.println(colored("\n\nHola MOai " , "mate_red") + "   --   mate_red");
		System.out.println(colored("Hola MOai " , "mate_green") + "   --   mate_green");
		System.out.println(colored("Hola MOai " , "mate_yellow") + "   --   mate_yellow");
		System.out.println(colored("Hola MOai " , "mate_blue") + "   --   mate_blue");
		System.out.println(colored("Hola MOai " , "mate_magenta") + "   --   mate_magenta");
		System.out.println(colored("Hola MOai " , "mate_cyan") + "   --   mate_cyan");
		System.out.println(colored("Hola MOai " , "white_darkgray") + "   --   white_darkgray");





	}

}
